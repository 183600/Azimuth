sudo -u $_REMOTE_USER /bin/bash -c "$(curl -fsSL https://cli.moonbitlang.com/install/unix.sh)"
