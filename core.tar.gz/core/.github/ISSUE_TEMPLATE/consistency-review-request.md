---
name: Consistency review request
about: Describe the behaviors that you find inconsistent
title: "[Consistency Review]"
labels: consistency review
assignees: ''

---

**Current behaviors**

**Expected behaviors**

**Justification**
